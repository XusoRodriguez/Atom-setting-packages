(function() {
  module.exports = {
    activate: function(state) {},
    deactivate: function() {}
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmlsZTovLy9DOi9Vc2Vycy9KUm9kci8uYXRvbS9wYWNrYWdlcy9hbmd1bGFyanMvbGliL2FuZ3VsYXJqcy5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFBQSxNQUFNLENBQUMsT0FBUCxHQUNFO0lBQUEsUUFBQSxFQUFVLFNBQUMsS0FBRCxHQUFBLENBQVY7SUFFQSxVQUFBLEVBQVksU0FBQSxHQUFBLENBRlo7O0FBREYiLCJzb3VyY2VzQ29udGVudCI6WyJtb2R1bGUuZXhwb3J0cyA9XG4gIGFjdGl2YXRlOiAoc3RhdGUpIC0+XG5cbiAgZGVhY3RpdmF0ZTogLT5cbiJdfQ==
