(function() {
  var FilecolorView;

  module.exports = FilecolorView = (function() {
    function FilecolorView(serializedState) {
      this.element = document.createElement('div');
      this.element.classList.add('filecolor');
      this.applyColors();
    }

    FilecolorView.prototype.serialize = function() {};

    FilecolorView.prototype.destroy = function() {
      return this.element.remove();
    };

    FilecolorView.prototype.getElement = function() {
      return this.element;
    };

    FilecolorView.prototype.removeColors = function() {
      var workspace;
      workspace = document.querySelector('atom-workspace');
      if (workspace) {
        return workspace.classList.remove('file-colors');
      }
    };

    FilecolorView.prototype.applyColors = function() {
      var workspace;
      workspace = document.querySelector('atom-workspace');
      if (workspace) {
        return workspace.classList.add('file-colors');
      }
    };

    return FilecolorView;

  })();

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmlsZTovLy9DOi9Vc2Vycy9KUm9kci8uYXRvbS9wYWNrYWdlcy9maWxlY29sb3IvbGliL2ZpbGVjb2xvci12aWV3LmNvZmZlZSJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUFBLE1BQUE7O0VBQUEsTUFBTSxDQUFDLE9BQVAsR0FDTTtJQUNTLHVCQUFDLGVBQUQ7TUFFWCxJQUFDLENBQUEsT0FBRCxHQUFXLFFBQVEsQ0FBQyxhQUFULENBQXVCLEtBQXZCO01BQ1gsSUFBQyxDQUFBLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBbkIsQ0FBdUIsV0FBdkI7TUFTQSxJQUFJLENBQUMsV0FBTCxDQUFBO0lBWlc7OzRCQWViLFNBQUEsR0FBVyxTQUFBLEdBQUE7OzRCQUdYLE9BQUEsR0FBUyxTQUFBO2FBQ1AsSUFBQyxDQUFBLE9BQU8sQ0FBQyxNQUFULENBQUE7SUFETzs7NEJBR1QsVUFBQSxHQUFZLFNBQUE7YUFDVixJQUFDLENBQUE7SUFEUzs7NEJBR1osWUFBQSxHQUFjLFNBQUE7QUFFWixVQUFBO01BQUEsU0FBQSxHQUFZLFFBQVEsQ0FBQyxhQUFULENBQXVCLGdCQUF2QjtNQUNaLElBQTZDLFNBQTdDO2VBQUEsU0FBUyxDQUFDLFNBQVMsQ0FBQyxNQUFwQixDQUEyQixhQUEzQixFQUFBOztJQUhZOzs0QkFLZCxXQUFBLEdBQWEsU0FBQTtBQUVYLFVBQUE7TUFBQSxTQUFBLEdBQVksUUFBUSxDQUFDLGFBQVQsQ0FBdUIsZ0JBQXZCO01BQ1osSUFBMEMsU0FBMUM7ZUFBQSxTQUFTLENBQUMsU0FBUyxDQUFDLEdBQXBCLENBQXdCLGFBQXhCLEVBQUE7O0lBSFc7Ozs7O0FBL0JmIiwic291cmNlc0NvbnRlbnQiOlsibW9kdWxlLmV4cG9ydHMgPVxuY2xhc3MgRmlsZWNvbG9yVmlld1xuICBjb25zdHJ1Y3RvcjogKHNlcmlhbGl6ZWRTdGF0ZSkgLT5cbiAgICAjIENyZWF0ZSByb290IGVsZW1lbnRcbiAgICBAZWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgQGVsZW1lbnQuY2xhc3NMaXN0LmFkZCgnZmlsZWNvbG9yJylcblxuICAgICMgQ3JlYXRlIG1lc3NhZ2UgZWxlbWVudFxuICAgICMgbWVzc2FnZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG4gICAgIyBtZXNzYWdlLnRleHRDb250ZW50ID0gXCJUaGUgRmlsZWNvbG9yIHBhY2thZ2UgaXMgQWxpdmUhIEl0J3MgQUxJVkUhXCJcbiAgICAjIG1lc3NhZ2UuY2xhc3NMaXN0LmFkZCgnbWVzc2FnZScpXG4gICAgIyBAZWxlbWVudC5hcHBlbmRDaGlsZChtZXNzYWdlKVxuXG4gICAgIyBhcHBseSBjb2xvcnNcbiAgICB0aGlzLmFwcGx5Q29sb3JzKClcblxuICAjIFJldHVybnMgYW4gb2JqZWN0IHRoYXQgY2FuIGJlIHJldHJpZXZlZCB3aGVuIHBhY2thZ2UgaXMgYWN0aXZhdGVkXG4gIHNlcmlhbGl6ZTogLT5cblxuICAjIFRlYXIgZG93biBhbnkgc3RhdGUgYW5kIGRldGFjaFxuICBkZXN0cm95OiAtPlxuICAgIEBlbGVtZW50LnJlbW92ZSgpXG5cbiAgZ2V0RWxlbWVudDogLT5cbiAgICBAZWxlbWVudFxuXG4gIHJlbW92ZUNvbG9yczogLT5cbiAgICAjIHJlbW92ZSBmaWxlIGNvbG9ycyBmcm9tIGF0b20td29ya3NwYWNlXG4gICAgd29ya3NwYWNlID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignYXRvbS13b3Jrc3BhY2UnKTtcbiAgICB3b3Jrc3BhY2UuY2xhc3NMaXN0LnJlbW92ZSgnZmlsZS1jb2xvcnMnKSBpZiB3b3Jrc3BhY2U7XG5cbiAgYXBwbHlDb2xvcnM6IC0+XG4gICAgIyBhcHBseSBmaWxlIGNvbG9ycyB0byBhdG9tLXdvcmtzcGFjZVxuICAgIHdvcmtzcGFjZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ2F0b20td29ya3NwYWNlJyk7XG4gICAgd29ya3NwYWNlLmNsYXNzTGlzdC5hZGQoJ2ZpbGUtY29sb3JzJykgaWYgd29ya3NwYWNlO1xuIl19
