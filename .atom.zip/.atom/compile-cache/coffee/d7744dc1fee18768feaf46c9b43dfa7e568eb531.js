(function() {
  var CompositeDisposable, Filecolor, FilecolorView;

  FilecolorView = require('./filecolor-view');

  CompositeDisposable = require('atom').CompositeDisposable;

  module.exports = Filecolor = {
    filecolorView: null,
    isActive: null,
    subscriptions: null,
    activate: function(state) {
      atom.packages.activatePackage('tree-view').then(function() {
        Filecolor.filecolorView = new FilecolorView(state.fileColorsViewState);
        Filecolor.isActive = true;
      });
      this.subscriptions = new CompositeDisposable;
      return this.subscriptions.add(atom.commands.add('atom-workspace', {
        'filecolor:toggle': (function(_this) {
          return function() {
            return _this.toggle();
          };
        })(this)
      }));
    },
    deactivate: function() {
      this.subscriptions.dispose();
      return this.filecolorView.destroy();
    },
    serialize: function() {
      return {
        filecolorViewState: this.filecolorView.serialize()
      };
    },
    toggle: function() {
      if (this.isActive === true) {
        this.isActive = false;
        this.filecolorView.removeColors();
      } else {
        this.isActive = true;
        this.filecolorView.applyColors();
      }
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiZmlsZTovLy9DOi9Vc2Vycy9KUm9kci8uYXRvbS9wYWNrYWdlcy9maWxlY29sb3IvbGliL2ZpbGVjb2xvci5jb2ZmZWUiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFBLGFBQUEsR0FBZ0IsT0FBQSxDQUFRLGtCQUFSOztFQUNmLHNCQUF1QixPQUFBLENBQVEsTUFBUjs7RUFFeEIsTUFBTSxDQUFDLE9BQVAsR0FBaUIsU0FBQSxHQUNmO0lBQUEsYUFBQSxFQUFlLElBQWY7SUFDQSxRQUFBLEVBQVUsSUFEVjtJQUlBLGFBQUEsRUFBZSxJQUpmO0lBTUEsUUFBQSxFQUFVLFNBQUMsS0FBRDtNQUNSLElBQUksQ0FBQyxRQUFRLENBQUMsZUFBZCxDQUE4QixXQUE5QixDQUEwQyxDQUFDLElBQTNDLENBQWdELFNBQUE7UUFDOUMsU0FBUyxDQUFDLGFBQVYsR0FBOEIsSUFBQSxhQUFBLENBQWMsS0FBSyxDQUFDLG1CQUFwQjtRQUM5QixTQUFTLENBQUMsUUFBVixHQUFxQjtNQUZ5QixDQUFoRDtNQVlBLElBQUMsQ0FBQSxhQUFELEdBQWlCLElBQUk7YUFHckIsSUFBQyxDQUFBLGFBQWEsQ0FBQyxHQUFmLENBQW1CLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBZCxDQUFrQixnQkFBbEIsRUFBb0M7UUFBQSxrQkFBQSxFQUFvQixDQUFBLFNBQUEsS0FBQTtpQkFBQSxTQUFBO21CQUFHLEtBQUMsQ0FBQSxNQUFELENBQUE7VUFBSDtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBcEI7T0FBcEMsQ0FBbkI7SUFoQlEsQ0FOVjtJQXdCQSxVQUFBLEVBQVksU0FBQTtNQUVWLElBQUMsQ0FBQSxhQUFhLENBQUMsT0FBZixDQUFBO2FBQ0EsSUFBQyxDQUFBLGFBQWEsQ0FBQyxPQUFmLENBQUE7SUFIVSxDQXhCWjtJQTZCQSxTQUFBLEVBQVcsU0FBQTthQUNUO1FBQUEsa0JBQUEsRUFBb0IsSUFBQyxDQUFBLGFBQWEsQ0FBQyxTQUFmLENBQUEsQ0FBcEI7O0lBRFMsQ0E3Qlg7SUFnQ0EsTUFBQSxFQUFRLFNBQUE7TUFFTixJQUFHLElBQUMsQ0FBQSxRQUFELEtBQWEsSUFBaEI7UUFFRSxJQUFDLENBQUEsUUFBRCxHQUFZO1FBQ1osSUFBQyxDQUFBLGFBQWEsQ0FBQyxZQUFmLENBQUEsRUFIRjtPQUFBLE1BQUE7UUFNRSxJQUFDLENBQUEsUUFBRCxHQUFZO1FBQ1osSUFBQyxDQUFBLGFBQWEsQ0FBQyxXQUFmLENBQUEsRUFQRjs7SUFGTSxDQWhDUjs7QUFKRiIsInNvdXJjZXNDb250ZW50IjpbIkZpbGVjb2xvclZpZXcgPSByZXF1aXJlICcuL2ZpbGVjb2xvci12aWV3J1xue0NvbXBvc2l0ZURpc3Bvc2FibGV9ID0gcmVxdWlyZSAnYXRvbSdcblxubW9kdWxlLmV4cG9ydHMgPSBGaWxlY29sb3IgPVxuICBmaWxlY29sb3JWaWV3OiBudWxsXG4gIGlzQWN0aXZlOiBudWxsXG5cbiAgIyBtb2RhbFBhbmVsOiBudWxsXG4gIHN1YnNjcmlwdGlvbnM6IG51bGxcblxuICBhY3RpdmF0ZTogKHN0YXRlKSAtPlxuICAgIGF0b20ucGFja2FnZXMuYWN0aXZhdGVQYWNrYWdlKCd0cmVlLXZpZXcnKS50aGVuIC0+XG4gICAgICBGaWxlY29sb3IuZmlsZWNvbG9yVmlldyA9IG5ldyBGaWxlY29sb3JWaWV3KHN0YXRlLmZpbGVDb2xvcnNWaWV3U3RhdGUpXG4gICAgICBGaWxlY29sb3IuaXNBY3RpdmUgPSB0cnVlO1xuICAgICAgcmV0dXJuXG5cbiAgICAjIEZpbGVjb2xvci5maWxlY29sb3JWaWV3ID0gbmV3IEZpbGVjb2xvclZpZXcoc3RhdGUuZmlsZUNvbG9yc1ZpZXdTdGF0ZSlcbiAgICAjIEZpbGVjb2xvci5pc0FjdGl2ZSA9IHRydWU7XG5cbiAgICAjIEBmaWxlY29sb3JWaWV3ID0gbmV3IEZpbGVjb2xvclZpZXcoc3RhdGUuZmlsZWNvbG9yVmlld1N0YXRlKVxuICAgICMgQG1vZGFsUGFuZWwgPSBhdG9tLndvcmtzcGFjZS5hZGRNb2RhbFBhbmVsKGl0ZW06IEBmaWxlY29sb3JWaWV3LmdldEVsZW1lbnQoKSwgdmlzaWJsZTogZmFsc2UpXG5cbiAgICAjIEV2ZW50cyBzdWJzY3JpYmVkIHRvIGluIGF0b20ncyBzeXN0ZW0gY2FuIGJlIGVhc2lseSBjbGVhbmVkIHVwIHdpdGggYSBDb21wb3NpdGVEaXNwb3NhYmxlXG4gICAgQHN1YnNjcmlwdGlvbnMgPSBuZXcgQ29tcG9zaXRlRGlzcG9zYWJsZVxuXG4gICAgIyBSZWdpc3RlciBjb21tYW5kIHRoYXQgdG9nZ2xlcyB0aGlzIHZpZXdcbiAgICBAc3Vic2NyaXB0aW9ucy5hZGQgYXRvbS5jb21tYW5kcy5hZGQgJ2F0b20td29ya3NwYWNlJywgJ2ZpbGVjb2xvcjp0b2dnbGUnOiA9PiBAdG9nZ2xlKClcblxuICBkZWFjdGl2YXRlOiAtPlxuICAgICMgQG1vZGFsUGFuZWwuZGVzdHJveSgpXG4gICAgQHN1YnNjcmlwdGlvbnMuZGlzcG9zZSgpXG4gICAgQGZpbGVjb2xvclZpZXcuZGVzdHJveSgpXG5cbiAgc2VyaWFsaXplOiAtPlxuICAgIGZpbGVjb2xvclZpZXdTdGF0ZTogQGZpbGVjb2xvclZpZXcuc2VyaWFsaXplKClcblxuICB0b2dnbGU6IC0+XG5cbiAgICBpZiBAaXNBY3RpdmUgPT0gdHJ1ZVxuICAgICAgIyByZW1vdmUgY29sb3JzXG4gICAgICBAaXNBY3RpdmUgPSBmYWxzZVxuICAgICAgQGZpbGVjb2xvclZpZXcucmVtb3ZlQ29sb3JzKClcbiAgICBlbHNlXG4gICAgICAjIGFwcGx5IGNvbG9yc1xuICAgICAgQGlzQWN0aXZlID0gdHJ1ZVxuICAgICAgQGZpbGVjb2xvclZpZXcuYXBwbHlDb2xvcnMoKVxuXG4gICAgcmV0dXJuXG4iXX0=
